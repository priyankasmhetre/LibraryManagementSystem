<?php
 include "connection.php";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Books</title>
	<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>
  <h2> List of Books </h2>
  <table>
  <tr>
    <th>Month</th>
    <th>Savings</th>
  </tr>
  <tr>
    <td>January</td>
    <td>$100</td>
  </tr>
  <tr>
    <td>February</td>
    <td>$80</td>
  </tr>
</table>
  <?php
  $res=mysqli_query($db,"SELECT * FROM `books`;");
  

 
	 while($row=mysqli_fetch_assoc($res))
	 {
		echo "<tr>";
		echo "<td>"; echo $row['bid'];        echo "</td>";
		echo "<td>"; echo $row['name'];       echo "</td>";
		echo "<td>"; echo $row['authors'];    echo "</td>";
		echo "<td>"; echo $row['edition'];    echo "</td>";
		echo "<td>"; echo $row['status'];     echo "</td>";
		echo "<td>"; echo $row['quantity'];   echo "</td>";
		echo "<td>"; echo $row['department']; echo "</td>";
		echo "</tr>";
	 }
	 echo "</table>";
	 
  ?>
  </body>
  </html>
  
 
