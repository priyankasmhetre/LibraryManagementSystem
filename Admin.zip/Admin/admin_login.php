<?php
   include "connection.php";
   session_start();
  ?> 

<!DOCTYPE html>
<html>
<head>
	<title>
		Student Login
	</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">


            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<style type="text/css">
	nav
	{
		float: right;
		word-spacing: 30px;
		padding: 20px;
	}
	nav li 
	{
		display: inline-block;
		line-height: 80px;
	}
</style>
</head>
<body>
<header>
      <div>
	  
	 
		</div>
			<nav>
				<ul>
					<li><a href="index.php">HOME</a></li>
					<li><a href="books.php">BOOKS</a></li>
					
					<li><a href="register.php">REGISTRATION</a></li>
					<li><a href="feedback.php">FEEDBACK</a></li>
				</ul>
			</nav>
</header>
<section>
<div class=login_img>
<br>
<div class="box1">
   <h1 style="text-align:center;font-size:35px;font-family:Lucida Console;color:white"> 
   Library Management System </h1>
    <h1 style="text-align:center;font-size:25px;color:white">
	Admin Login Form </h1>
	<form name="login" action=""method="post">
	<div class="login">
   <input class="form-control" type="text" name="username" placeholder="Username" required=""><br>
   <input  class="form-control"type="text" name="password" placeholder="Password" required=""><br><br>
   <input class="btn btn-default" type="submit" name="submit" value="Login" style="color:black; width:60px;height:30px"></div>
   </form>
   <br>
   <p style="color:white;">
   <a  style="color:white;"href="update_password.php">forgot password</a> &nbsp &nbsp
    <a  style="color:white;"href="register.php">Sign Up</a>
</div>
</div>

</section>
<?php
    if(isset($_POST['submit']))
	{    $count=0;
		$res=mysqli_query($db,"SELECT * FROM `admin` WHERE username='$_POST[username]' AND password='$_POST[password]';");
		$count=mysqli_num_rows($res);
		if($count==0)
		{
			?>
			    <!--
			    <script type="text/javascript">
			    alert("the username and password does'nt match.");
			    </script>
			    -->
			
				  <div class="alert alert-danger" style="width: 700px; margin-left:300px">
				  <strong> The username and password doesn't match </strong>
				  </div>
			<?php
		}
		else{
		$_SESSION['login_user']=$_POST['username'];
		
			?>
			    
				
				
			      <script type="text/javscript">
			      window.location = "index.php ";
			      </script>
				  
			<?php
			
			
		}
	}

?>

</body>
</html> 